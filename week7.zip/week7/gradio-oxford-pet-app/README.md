## 📊 Evaluation: Zero-Shot (CLIP)

Zero Shot prediction:
- Accuracy: 90%

Zero Shot Results:

- Accuracy: 0.9000
- Precision: 0.8500
- Recall: 0.9000

