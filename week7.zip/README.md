# AI-Application Course  

## Sample Documentation of End-of-Module Exam  

 Description                 | Link |  
|-----------------------------|------------------------------------------------|  
| End-to-End Application      | [README.md](end-of-module-exam-doc/end-to-end-application/README.md) |  
| Computer Vision Example     | [README.md](end-of-module-exam-doc/computer-vision/README.md) |  
